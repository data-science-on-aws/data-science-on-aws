# Module 2 - Machine Learning with RAPIDS

This lab should take 60 to 120 minutes. It covers the end to end workflow for data science.

* Intro to RAPIDS libraries
* Data Download
* Data Processing
* Data Visualization
* Model Training
* Model Inference
* HPO

# Local testing

Sections 1-6 of this lab do not require any AWS specific components and can be run on any system with a single 16GB+ V100 or newer GPU.

To run the lab build the included `Dockerfile` and run the container. Jupyter Lab will automatically start in the correct location.

Build:
```sh
Docker build . -t coursera_aws_rapids:latest
```

Run:
```sh
docker run -it -v /home/atetelman/repo/coursera/module_2_rapids/src:/home/ec2-user/SageMaker -p 9999:8888 coursera_aws_rapids:latest
```

Once in Jupyter, each of the notebooks can be opened. The notebook names begin with 01, 02, 03, 04, 05, 06, and 07  and should be run in that order. Each notebook relies in the previous notebook for data download/processing/etc.

Notebook 07 relies on AWS components for HPO and cannot be run locally without some work.

Reach out to Adam Tetelman (atetelman@nvidia.com) for further details or questions. The original script draft can be found [here](https://docs.google.com/document/d/1pw0airoG6_hP0mYFHOQKVX9sKHJbBWTqGfjfJDoyNUA/edit#).
