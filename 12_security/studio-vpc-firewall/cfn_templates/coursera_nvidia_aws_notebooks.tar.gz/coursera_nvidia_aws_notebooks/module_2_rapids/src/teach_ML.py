import matplotlib.pyplot as plt
import copy
import cudf
import pydeck
import numpy
import pprint
import xgboost

# TODO: 
MAPBOX_KEY = "pk.eyJ1IjoiaXB5bWFwYm94IiwiYSI6ImNrOWwxM2g4MTA2ankzZnFwcGlvbXNvMWoifQ.v4Pe5Fq-hXJaUxMPt1Qkrw"

def augment_dataset_inplace ( data, data_dir, base_lib ):

    initial_column_set = set ( data.columns )

    carriers = base_lib.DataFrame(); airports = cudf.DataFrame()

    # ingest
    carriers = base_lib.read_csv( data_dir + 'carriers.csv')
    airports = base_lib.read_csv( data_dir + 'airports.csv', 
                                usecols= ['iata_code', 'latitude_deg',
                                        'longitude_deg',  'elevation_ft'])            
    # merge         
    data = base_lib.merge(data, carriers, left_on='IATA_CODE_Reporting_Airline', right_on='Code', how='left')
    data = base_lib.merge(data, airports, left_on='Dest', right_on='iata_code', how='left')
    data = base_lib.merge(data, airports, left_on='Origin', right_on='iata_code', how='left')            

    # rename [ for clarity]
    data = data.rename(columns= { 'latitude_deg_x' : 'dest_lat', 'longitude_deg_x': 'dest_long',
                                  'latitude_deg_y' : 'origin_lat', 'longitude_deg_y': 'origin_long',
                                  'elevation_ft_x' : 'dest_elevation', 'elevation_ft_y' : 'origin_elevation',
                                  'Description' : 'Airline'})

    # remove duplicates columns
    data = data.drop(['iata_code_x', 'iata_code_y','IATA_CODE_Reporting_Airline', 'Code'], axis=1)

    print( f'added the following columns/features:\n { set ( data.columns ).difference ( initial_column_set ) }')

    del( carriers, airports ) # clean-up the dataset components we used to build the combined dataset    

    return data

def geo_plot( filtered_data, 
              num_to_display = 5000,
              plotting_features = ['origin_long', 'origin_lat', 
                                   'dest_long', 'dest_lat', 
                                   'OriginCityName','DestCityName', 
                                   'height']  ):    
    
    stride = 1

    if (num_to_display <= filtered_data.shape[0]): 
        stride = int(filtered_data.shape[0] / num_to_display)

    GREEN_RGB = [0, 255, 0, 75]
    RED_RGB = [240, 100, 0, 75]

    arc_layer = pydeck.Layer( "ArcLayer",
                              data = filtered_data[ plotting_features ].iloc[ ::stride ].iloc[ :num_to_display ].to_pandas(),
                              get_width = 5, get_tilt = 10,
                              get_height = ['height'],
                              get_source_position=['origin_long', 'origin_lat'],
                              get_target_position=['dest_long', 'dest_lat'],
                              get_source_color=GREEN_RGB,
                              get_target_color=RED_RGB,
                              pickable=True,
                              auto_highlight=True )
    
    # USA centered map
    view_state = pydeck.ViewState( latitude=30, longitude=-100, bearing=0, pitch=0, zoom=2 )

    renderer = pydeck.Deck( arc_layer, initial_view_state = view_state,
                            mapbox_key = MAPBOX_KEY,
                            map_style = 'mapbox://styles/mapbox/satellite-v9' )
    return renderer


def compare_speedups( log : dict = {} , 
                      delimiter : str = '_',
                      print_summary : bool = True,
                      plot_figure : bool = True ):

    log_copy = copy.deepcopy( log )
    matched_ops = {}

    while log_copy:
        candidate_key = list( enumerate( log_copy.keys() ) )[0][1]    
        candidate_key_value = log_copy.pop( candidate_key )
        candidate_op_code = candidate_key.split(delimiter)[0:-1][0]
        candidate_compute_type = candidate_key.split(delimiter)[-1]
        
        for ikey in log_copy.keys():
            ikey_op_code = ikey.split('_')[0:-1][0]
            ikey_compute_type = ikey.split('_')[-1]
            
            if candidate_op_code == ikey_op_code \
                and candidate_compute_type != ikey_compute_type:
                
                # print(f'{candidate_key}, {candidate_key_value}, {candidate_op_code}, {candidate_compute_type}')
                # print(f'{ikey}, {log_copy[ikey]}, {ikey_op_code}, {ikey_compute_type}')

                if ikey_compute_type.lower() == 'gpu':
                    assert(candidate_compute_type.lower() == 'cpu')
                    gpu_val = log_copy[ikey]
                    cpu_val = candidate_key_value
                    
                elif ikey_compute_type.lower() == 'cpu':
                    assert(candidate_compute_type.lower() == 'gpu')
                    gpu_val = candidate_key_value
                    cpu_val = log_copy[ikey]
                
                ratio = cpu_val / gpu_val                 
                
                matched_ops.update( { candidate_op_code : [ cpu_val, gpu_val, ratio ]} )

    # print summary
    if print_summary:
        if matched_ops:
            print( 'found benchmark pairs for the following operations:')
            for op in matched_ops.keys():
                print( f'> {op} : speedup: {matched_ops[op][2]:.2f} x  -- cpu: {matched_ops[op][0]:.2f} seconds, gpu: {matched_ops[op][1]:.2f} seconds' )

    if plot_figure:
        pass
        #plt.figure()
        #plt.barh()

    return matched_ops


def polar_plot_results( matched_ops, ZOOMED_FLAG = False ):
    plt.figure( figsize = ( 10, 10 ) )
    ax = plt.subplot( 111, polar = True )
    ax.set_theta_offset( numpy.pi / 2)
    ax.set_theta_direction( -1 )

    # angle of each axis in the plot depends on the number of variables
    N = len(matched_ops)
    angles = [n / float(N) * 2 * numpy.pi for n in range(N)]

    # draw ylabels [ second markers ]
    if ZOOMED_FLAG:
        ax.set_rlabel_position(0)
        plt.yticks([10,20,30,40,50], ["10s","20s","30s","40s","50s"], color="grey", size=8)
        plt.ylim(0,35)

    # draw CPU and GPU values
    cpu_values = [ value[0] for key, value in matched_ops.items() ]
    gpu_values = [ value[1] for key, value in matched_ops.items() ]
    ax.fill(angles, cpu_values, 'royalblue', alpha=0.3, label="CPU")
    ax.fill(angles, gpu_values, 'limegreen', label="GPU")

    # title, legend, and feature-name xticks
    ax.set_title( "Time Per Data Science Task", size = 15, pad = 15 )
    plt.legend( loc = "upper right")
    plt.xticks(angles, matched_ops, size = 15)

    plt.show()

    
def train_model ( X_train, y_train, model_type = 'XGBoost', model_params = {}, compute_type = 'GPU' ):
    
    n_estimators = model_params.get('num_boost_round') or model_params.get('n_estimators') 
    
    print( f'training {model_type} classifier on {compute_type} with {n_estimators} estimators')
    pprint.pprint(model_params)
    
    if 'XGBoost' in model_type:
        
        dtrain = xgboost.DMatrix(data = X_train, label = y_train)
        
        trained_model = xgboost.train( dtrain = dtrain, params = model_params, 
                                       num_boost_round = n_estimators, verbose_eval=False)

    elif 'RandomForest' in model_type:

        if 'GPU' in compute_type:
            from cuml.ensemble import RandomForestClassifier
            rf_model = RandomForestClassifier ( n_estimators = n_estimators,
                                                max_depth = model_params['max_depth'],
                                                max_features = model_params['max_features'] )            
        elif 'CPU' in compute_type:
            from sklearn.ensemble import RandomForestClassifier
            rf_model = RandomForestClassifier ( n_estimators = n_estimators,
                                                max_depth = model_params['max_depth'],
                                                max_features = model_params['max_features'], 
                                                n_jobs = model_params['n_jobs'] )

        trained_model = rf_model.fit( X_train, y_train )

    return trained_model