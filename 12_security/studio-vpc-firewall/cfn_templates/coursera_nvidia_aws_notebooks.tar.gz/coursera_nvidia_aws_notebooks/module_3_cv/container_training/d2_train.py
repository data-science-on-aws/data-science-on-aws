import logging
import os
import sys
import subprocess
import tarfile

# verify contents of /opt/ml/code
# os.system('echo ------------------')
# os.system('echo contents of /opt/ml/code:')
# os.system('ls /opt/ml/code')
# os.system('echo ------------------')

from collections import OrderedDict
import torch
from torch.nn.parallel import DistributedDataParallel
import torch.distributed as dist

import detectron2.utils.comm as comm
from detectron2.checkpoint import DetectionCheckpointer, PeriodicCheckpointer
from detectron2.config import get_cfg
from detectron2.data import (
    DatasetCatalog,
    MetadataCatalog,
    build_detection_test_loader,
    build_detection_train_loader,
)
from detectron2.engine import default_argument_parser, default_setup, launch
from detectron2.evaluation import (
#     CityscapesEvaluator,
    COCOEvaluator,
    COCOPanopticEvaluator,
    DatasetEvaluators,
    LVISEvaluator,
    PascalVOCDetectionEvaluator,
    SemSegEvaluator,
    inference_on_dataset,
    print_csv_format,
)
from detectron2.modeling import build_model
from detectron2.solver import build_lr_scheduler, build_optimizer
from detectron2.utils.events import (
    CommonMetricPrinter,
    EventStorage,
    JSONWriter,
    TensorboardXWriter,
)
import detectron2.data.transforms as T
from detectron2.data import DatasetMapper 
from detectron2.structures import BoxMode
from detectron2.data.datasets import register_coco_instances

import pandas as pd
import numpy as np
import itertools
import boto3
import subprocess
import argparse
import json
from train_funcs import *
from build import *

logger = logging.getLogger('detectron2')

CONFIGS_BASE = './detectron2/configs'
WEIGHTS_BASE = 'detectron2://' # https://dl.fbaipublicfiles.com/detectron2/
BASE_DIR = os.environ['SM_CHANNEL_TRAIN']
IMAGES_BASE = os.environ['SM_CHANNEL_TRAIN'] + '/images'
images_list = os.listdir(IMAGES_BASE)
print(f'images base: {IMAGES_BASE} has {len(images_list)} files')

# From Detectron2 Model Zoo: https://github.com/facebookresearch/detectron2/blob/master/MODEL_ZOO.md

# os.environ['FORCE_CUDA'] = '1'
# os.environ['TORCH_CUDA_ARCH_LIST'] = 'Volta'
# os.environ['FVCORE_CACHE'] = '/tmp'
os.environ['DETECTRON2_DATASETS'] = IMAGES_BASE

    

def main(args):
    if args.sample_size > 0:
        val_file = f'{BASE_DIR}/samples_birds_{args.sample_size}_val.json'
        train_file = f'{BASE_DIR}/samples_birds_{args.sample_size}_train.json'
        test_file = f'{BASE_DIR}/samples_birds_{args.sample_size}_test.json'
    else:
        val_file = f'{BASE_DIR}/instances_birds_val.json'
        train_file = f'{BASE_DIR}/instances_birds_train.json'
        test_file = f'{BASE_DIR}/instances_birds_test.json'

    register_coco_instances('birds_train', {}, image_root=IMAGES_BASE, json_file=train_file)
    register_coco_instances('birds_val', {}, image_root=IMAGES_BASE, json_file=val_file)
    register_coco_instances('birds_test', {}, image_root=IMAGES_BASE, json_file=test_file)

    cfg = setup(args)
#     print(cfg)

    model = build_model(cfg)
    logger.info("Model:\n{}".format(model))
    if args.eval_only:
        DetectionCheckpointer(model, save_dir=cfg.OUTPUT_DIR).resume_or_load(
            cfg.MODEL.WEIGHTS, resume=args.resume
        )
        return do_test(cfg, model)

    distributed = comm.get_world_size() > 1
    if distributed:
        if args.ddp==1:
            print('Using Distributed Data Parallel')
#             dist.init_process_group("nccl", rank=comm.get_rank(), world_size=comm.get_world_size()) # doing this by default already
            model = DistributedDataParallel(
                model, device_ids=[comm.get_local_rank()], broadcast_buffers=False
            )
        else:
            print('Using standard Data Parallel')
            num_gpus = int(os.environ['SM_NUM_GPUS'])
            devices = np.arange(num_gpus).tolist()
            model = torch.nn.DataParallel(model, device_ids=[comm.get_local_rank()])

    do_train(cfg, model, args.pin_memory) # logger
    return do_test(cfg, model)


if __name__ == "__main__":
    
    print('Starting training...')

    # might want to move argparser to main function 
    parser = argparse.ArgumentParser()
    parser.add_argument("--dist_url", type=str, default='tcp://127.0.0.1:49152')
    parser.add_argument('--model_config', type=str, default='/opt/ml/code/COCO-Detection/faster_rcnn_X_101_32x8d_FPN_3x.yaml')
    parser.add_argument('--ims_per_batch', type=int, default=2)
    parser.add_argument('--pre_nms_topk_train', type=int, default=5000)
    parser.add_argument('--nms_thresh', type=float, default=0.8)
    parser.add_argument('--ddp', type=int, default=1)
    parser.add_argument('--pin_memory', type=int, default=1)
    parser.add_argument('--num_dataloader_workers', type=int, default=1)
    parser.add_argument('--num_iters', type=int, default=3000)
    parser.add_argument('--base_lr', type=float, default=0.01)
    parser.add_argument('--lr_steps', type=str, default='1000,2000,3000,4000,5000,6000,7000,8000,9000')
    parser.add_argument('--gamma', type=float, default=0.2)
    parser.add_argument('--rpn_batch_size', type=int, default=64)
    parser.add_argument('--eval_rate', type=float, default=0.25)
    parser.add_argument('--sample_size', type=int, default=11)
    parser.add_argument("--eval_only", type=bool, default=False)
    # parser.add_argument("--ignore_display", dest="display", action="store_false", default=True)
#    parser.add_argument("--local_rank", default=0)
    parser.add_argument("--machine_rank", type=int, default=0)
#    parser.add_argument("--num_gpus", type=int, default=8)
#    parser.add_argument("--num_machines", type=int, default=1)
    parser.add_argument("--resume", type=str, default="False")
    parser.add_argument("--opts", type=list, default=[])
    parser.add_argument("--spot_ckpt", default='')


    args, unknown = parser.parse_known_args()    

    if unknown:
        print(f'The following arguments were not recognized and will not be used: {unknown}')

    num_gpus = int(os.environ['SM_NUM_GPUS'])
    sm_hosts = os.environ['SM_HOSTS']
    num_hosts = sm_hosts.count(',') + 1
    print(os.environ['SM_MODULE_DIR'])
    print(f'\nSM_HOSTS: {sm_hosts}, num gpus: {num_gpus}, num hosts: {num_hosts}')
        
    launch(
        main,
        num_gpus,
        num_machines=num_hosts,
        machine_rank=args.machine_rank,
        dist_url=args.dist_url,
        args=(args,),
    )